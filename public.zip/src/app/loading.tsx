'use client';
import { Skeleton } from '@mantine/core';

export default function Loading() {
  return <Skeleton height={'100%'} width={'100%'} />;
}
